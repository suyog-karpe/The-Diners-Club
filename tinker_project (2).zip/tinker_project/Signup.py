from tkinter import *
from turtle import bgcolor
import tkinter as tk
from PIL import ImageTk,Image
# from matplotlib.pyplot import text

def signup(root):
    top=Toplevel(root)
    top.geometry("1240x610")
    top.configure(bg='gray51')


    loginLabel = Label(top, text="➊", fg='black', bg='gray51', font=('Arial 23 '))
    loginLabel.place(x=300, y=30)
    loginLabel = Label(top, text="Sign Up", fg='black', bg='gray51', font=('Arial 10 bold '))
    loginLabel.place(x=290, y=70)
    loginLabel = Label(top, text="Get login through any account", fg='white', bg='gray51', font=('Arial 10  '))
    loginLabel.place(x=230, y=90)
    HORIZONTAL =Frame(top, bg='black', height=1,width=200).place(x=330,y=48)
    loginLabel = Label(top, text="➁", fg='black', bg='gray51', font=('Arial 23 '))
    loginLabel.place(x=490, y=30)
    loginLabel = Label(top, text="Select your Club", fg='black', bg='gray51', font=('Arial 10 bold '))
    loginLabel.place(x=460, y=70)
    loginLabel = Label(top, text="Goto Getway", fg='white', bg='gray51', font=('Arial 10  '))
    loginLabel.place(x=470, y=90)
    HORIZONTAL =Frame(top, bg='black', height=1,width=200).place(x=530,y=48)
    loginLabel = Label(top, text="➂", fg='black', bg='gray51', font=('Arial 23 '))
    loginLabel.place(x=690, y=30)
    loginLabel = Label(top, text="Pay via UPI", fg='black', bg='gray51', font=('Arial 10 bold '))
    loginLabel.place(x=670, y=70)
    loginLabel = Label(top, text="Available 24/7", fg='white', bg='gray51', font=('Arial 10  '))
    loginLabel.place(x=670, y=90)
    HORIZONTAL =Frame(top, bg='black', height=1,width=200).place(x=720,y=48)
    loginLabel = Label(top, text="➃", fg='black', bg='gray51', font=('Arial 23 '))
    loginLabel.place(x=900, y=30)
    loginLabel = Label(top, text="Get Exciting Offers", fg='black', bg='gray51', font=('Arial 10 bold '))
    loginLabel.place(x=870, y=70)
    loginLabel = Label(top, text="Terma and Conditions Apply", fg='white', bg='gray51', font=('Arial 10  '))
    loginLabel.place(x=850, y=90)


    logo_icon = ImageTk.PhotoImage(Image.open("LOGO.png").resize((228, 80)))
    logo_icon_label = Label(top,image=logo_icon).place(x=530,y=150)

    usernameLabel = Label(top, text="Email*", width="12", fg='white', bg='gray51',font="Arial 10 bold ")
    username = StringVar()
    usernameLabel.place(x=500, y=250)
    usernameEntry = Entry(top, textvariable=username.get(), bg='gray')
    usernameEntry.place(x=530, y=280)

    passwordLabel = Label(top ,text="Password*", width="12", fg='white', bg='gray51',font="Arial 10 bold ")  
    password = StringVar()
    passwordLabel.place(x=510, y=300)
    passwordEntry = Entry(top, textvariable=password.get(), show='*', bg='gray')
    passwordEntry.place(x=530, y=330)
    print('password', password)


    def Log():
        if (passwordEntry.get()=='root' and usernameEntry.get()=='root'):
            tk.messagebox.showinfo(" logged"," login successfull")
        else:
            tk.messagebox.showinfo("Invalid Login","Use Correct Credentials.")

    b1 = Button(top,text = "Continue",width="10",bd="1",bg='beige', fg='black', font="Arial 12 ",command=Log) 
    b1.place(x=600,y=380) 



    #line1 = Canvas.create_line(96,326,106,326, width=5)
    orLabel = Label(top, text="OR",fg='white', bg='black', width="3")
    orLabel.place(x=630, y=430)

    my_canvas = Canvas(top, width=310, height=550, bg="blue")
    my_canvas.create_line(135,325,200,370,fill='white', width=5)


    def google():
        tk.messagebox.showinfo("Google"," Connecting to google")

    def facebook():
        tk.messagebox.showinfo("Facebook"," Connecting to facebook")

    def twitter():
        tk.messagebox.showinfo("twitter"," Connecting to twitter")

    click_btn= PhotoImage(file= r'Google.png')
    googleButton = Button(top, image=click_btn, command=google)
    googleButton.place(x=350, y=480)

    click_btn2= PhotoImage(file= r'Facebook.png')
    facebookButton = Button(top, image=click_btn2, command=facebook)
    facebookButton.place(x=580, y=480)

    click_btn3= PhotoImage(file= r'Twitter.png')
    linkButton = Button(top, image=click_btn3, command=twitter)
    linkButton.place(x=800, y=480)

    top.mainloop()