import tkinter.font as font
from tkinter import *
from tkinter import messagebox

from PIL import ImageTk,Image
import Signup

root=Tk()
# root.state('zoomed') 
root.geometry('1280x720')
root['background']='#FFFFFF'

# root.wm_attributes('-transparentcolor', 'gray51')

vertical =Frame(root, bg='gray51', height=84,width=1280).place(x=0,y=0)

logo_icon = ImageTk.PhotoImage(Image.open("LOGO.png").resize((228, 80)))
logo_icon_label = Label(image=logo_icon).place(x=0,y=0)

def helloCallBack():
   messagebox.showinfo( "HOME", "Home.py")
B = Button(text ="HOME", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#EEE1C6',foreground='Black').place(x=287,y=26)
def helloCallBack():
   messagebox.showinfo( "Offers", "Offers.py")
B = Button(text ="OFFERS", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#EEE1C6',foreground='Black').place(x=447,y=26)
def helloCallBack():
   messagebox.showinfo( "Contact Us", "Contact Us.py")
B = Button(text ="CONTACT US", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#EEE1C6',foreground='Black').place(x=593,y=26)
def helloCallBack():
   messagebox.showinfo( "About Us", "AboutUs.py")
B = Button(text ="ABOUT US", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#EEE1C6',foreground='Black').place(x=747,y=26)


def helloCallBack():
   Signup.signup(root)
   
B = Button(text ="Sign In", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#EEE1C6',foreground='Black').place(x=1134,y=27)




#selectpane =Frame(root, bg='#999999', height=36,width=870).place(x=24,y=94)
clicked= StringVar()
clicked.set("Search")
main_menu = OptionMenu(root, clicked, "Home.py", "Offers.py", "ContactUs.py","Offers.py",)
main_menu.config(width=20)
main_menu.place(x=1100,y=97)


logo_i = ImageTk.PhotoImage(Image.open("sl.png").resize((450, 250)))
logo_i_label = Label(image=logo_i).place(x=74,y=170)
HORIZONTAL =Frame(root, bg='#000000', height=300,width=1).place(x=640,y=150)
loginLabel = Label(root, text="2BHK Diner & Keyclub", fg='black', bg='white', font=('Arial 23 '))
loginLabel.place(x=750, y=240)
loginLabel = Label(root, text="The Mills,Bund Garden", fg='black', bg='white', font=('Arial 18 '))
loginLabel.place(x=750, y=290)
loginLabel = Label(root, text="Road,Pune", fg='black', bg='white', font=('Arial 16 '))
loginLabel.place(x=750, y=320)
def helloCallBack():
   messagebox.showinfo( "BookNow.py", "Currently Closed")
B = Button(text ="Book Now", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#000000',foreground='white').place(x=755,y=360)
def helloCallBack():
   messagebox.showinfo( "View.py", "Currently no offers!")
B = Button(text ="View Offers >", command = helloCallBack,height=2,width=15,font=font.Font(family='Arial', size=9),bg='#FFFFFF',foreground='black').place(x=890,y=360)
logo_ib = ImageTk.PhotoImage(Image.open("sn.png").resize((90, 25)))
logo_ib_label = Label(image=logo_ib).place(x=755,y=420)





vertical =Frame(root, bg='#673FB4', height=200,width=1250).place(x=15,y=480)
loginLabel = Label(root, text="Book Now and Get Exciting Offers", fg='black', bg='#673FB4', font=('Arial 20 underline'))
loginLabel.place(x=50, y=500)
loginLabel = Label(root, text="✓ Get A Free Pitcher for a Booking of Rs1200", fg='black', bg='#673FB4', font=('Arial 16 '))
loginLabel.place(x=50, y=540)
loginLabel = Label(root, text="✓ Get 2 shots @Rs900", fg='black', bg='#673FB4', font=('Arial 16 '))
loginLabel.place(x=50, y=570)
loginLabel = Label(root, text="✓ Get Cocktals Free @Rs1500", fg='black', bg='#673FB4', font=('Arial 16 '))
loginLabel.place(x=50, y=600)
loginLabel = Label(root, text="X  ̶F̶r̶e̶e̶ ̶E̶n̶t̶r̶y̶ ̶f̶o̶r̶ ̶W̶o̶m̶e̶n̶ ̶o̶n̶ ̶W̶e̶d̶n̶e̶s̶d̶a̶y̶ ", fg='black', bg='#673FB4', font=('Arial  16 '))
loginLabel.place(x=50, y=630)
logo_i1 = ImageTk.PhotoImage(Image.open("sk.png").resize((230, 130)))
logo_i1_label = Label(image=logo_i1).place(x=990,y=520)





vertical =Frame(root, bg='#999999', height=1,width=1256).place(x=10,y=695)

root.mainloop()
